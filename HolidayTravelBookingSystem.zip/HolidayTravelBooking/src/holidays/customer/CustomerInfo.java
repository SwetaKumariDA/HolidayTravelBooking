package holidays.customer;

import java.util.*;

import javax.swing.JOptionPane;

import java.io.*;

import holidays.components.Event;

public class CustomerInfo {

	private BufferedReader readFile;
	ArrayList<Customer> custList = new ArrayList<Customer>();

	public CustomerInfo() {
		loadCustomerInfo();
	}

	/**
	 *  function read the data from CustomerInfo.csv file and load the data
	 */
	private void loadCustomerInfo() {
		try {
			File custData = new File("src/CustomerInfo.csv");
			BufferedReader br = new BufferedReader(new FileReader(custData));
			String st;
			while ((st = br.readLine()) != null) {
				Customer evt = loadCustomer(st);
				custList.add(evt);
			}

		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	private Customer loadCustomer(String st) {
		String custDetails[] = st.split(",");
		Customer evtt = new Customer();
		evtt.setUserID(custDetails[0]);
		evtt.setPassword(custDetails[1]);
		evtt.setFirstName(custDetails[2]);
		evtt.setLastName(custDetails[3]);
		return evtt;
	}
	
   public boolean isUserExist(String userID, char[] pass) {
		
		for (Customer et : custList) {
			if (et.getUserID().equals(userID) && et.getPassword().equals(new String(pass))) {
				return true;
			}
		}

		return false;
	}
   
   public boolean isUserIdExist(String userId) {
	   
		for (Customer et : custList) {
			if (et.getUserID().equals(userId)) {
				return true;
			}
		}

		return false;
		
	}
	
	
	/** Function writes the user information in the file
	 * @param userDetails
	 * @return
	 */
	public boolean writeToDB(String userDetails) {
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter("src/CustomerInfo.csv", true));
			out.write(userDetails);
			out.close();
			loadCustomerInfo();		
		} catch (IOException e) {
			System.out.println("exception occoured while adding user" + e);
			return false;
		}
		return true;

	}

	public Customer custDetails(String userID) {
		Customer cust=new Customer();
		
		for (Customer et : custList) {
			if (et.getUserID().equals(userID)) {
				return et;
			}
		}
		return cust;
	}
    


}
