package holidays.providers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import holidays.components.RentalCar;
import holidays.components.Car;

public class RentalCarProviders {

	ArrayList<RentalCar> rentalCarList = new ArrayList<RentalCar>();

	public RentalCarProviders() {
		loadRentalCarData();
	}

	/**
	 *  function read the data from RentalCars.csv file and load the data
	 */
	private void loadRentalCarData() {
		
		try {
			File flightData = new File("src/RentalCars.csv");
			BufferedReader br = new BufferedReader(new FileReader(flightData));
			String st;
			while ((st = br.readLine()) != null) {
				RentalCar rentcar = loadRentalCar(st);
				rentalCarList.add(rentcar);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}


	
	private RentalCar loadRentalCar(String line) {
		String rentalCardetails[] = line.split(",");
		RentalCar rentCar = new RentalCar();
		Car car = new Car();
//		hotel.setId(Integer.parseInt(hoteldetails[0]));
		rentCar.setCountryName(rentalCardetails[0]);
		rentCar.setCityName(rentalCardetails[1]);
		rentCar.setServiceProviders(rentalCardetails[2]);
		rentCar.setCarPickUpLocation(rentalCardetails[5]);
		rentCar.setDateAvailability(rentalCardetails[6]);
		rentCar.setCost(Double.parseDouble(rentalCardetails[7]));
		car.setCarType(rentalCardetails[3]);
		car.setDescription(rentalCardetails[4]);
		rentCar.setCarInfo(car);

		return rentCar;
	}

	/** 
	 * function gives the list for rental cars for given country,city and date
	 * @param country
	 * @param city
	 * @param userDates
	 * @return list of rental cars
	 */	
	public List<RentalCar> carsByKey(String country, String city, String[] userDates) {
		List<RentalCar> searchedHotelList = new ArrayList<>();


		for (RentalCar rc : rentalCarList) {
			if (rc.getCountryName().equals(country) && rc.getCityName().equals(city)){
				int flag=0;
				
				String[] dates= rc.getDateAvailability().split("#");
				for(int i=0;i<dates.length;i++) {
					for(int j=0;j<userDates.length;j++) {
						if(userDates[j].equals(dates[i])) {
							flag++;
						}
					}
				}
				if(userDates.length==flag){
					searchedHotelList.add(rc);
				}
				

			}

		}
		return searchedHotelList;
	}




}
