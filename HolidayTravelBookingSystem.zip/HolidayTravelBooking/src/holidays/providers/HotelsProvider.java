package holidays.providers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import holidays.components.Hotel;
import holidays.components.Room;

public class HotelsProvider {

	ArrayList<Hotel> hotelList = new ArrayList<Hotel>();

	public HotelsProvider() {
		loadHotelData();
	}

	/**
	 *  function read the data from Hotels.csv file and load the data
	 */
	private void loadHotelData() {
		
		try {
			File flightData = new File("src/Hotels.csv");
			BufferedReader br = new BufferedReader(new FileReader(flightData));
			String st;
			while ((st = br.readLine()) != null) {
				Hotel hotel = loadHotel(st);
				hotelList.add(hotel);
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	private Hotel loadHotel(String line) {
		String hoteldetails[] = line.split(",");
		Hotel hotel = new Hotel();
		Room room = new Room();
//		hotel.setId(Integer.parseInt(hoteldetails[0]));
		hotel.setHotelName(hoteldetails[0]);
		hotel.setDescription(hoteldetails[1]);
		hotel.setCountryName(hoteldetails[2]);
		hotel.setCityName(hoteldetails[3]);
		hotel.setCheckinTime(hoteldetails[4]);
		hotel.setCheckoutTime(hoteldetails[5]);
		hotel.setDateAvailability(hoteldetails[6]);
		hotel.setCost(Double.parseDouble(hoteldetails[7]));
		room.setRoomType(hoteldetails[8]);
		room.setDescription(hoteldetails[9]);
		hotel.setRoomInfo(room);

		return hotel;
	}

	
	

	/** function gives the list for hotels for given country,city and date
	 * @param country 
	 * @param city
	 * @param userDates
	 * @return list of hotels
	 */
	public List<Hotel> searchHotelsByKey(String country, String city, String[] userDates) {
		List<Hotel> searchedHotelList = new ArrayList<>();


		for (Hotel ht : hotelList) {
			if (ht.getCountryName().equals(country) && ht.getCityName().equals(city)){
				int flag=0;
				
				String[] dates= ht.getDateAvailability().split("#");
				for(int i=0;i<dates.length;i++) {
					for(int j=0;j<userDates.length;j++) {
						if(userDates[j].equals(dates[i])) {
							flag++;
						}
					}
				}
				if(userDates.length==flag){
					searchedHotelList.add(ht);
				}
				

			}

		}
		return searchedHotelList;
	}



}
