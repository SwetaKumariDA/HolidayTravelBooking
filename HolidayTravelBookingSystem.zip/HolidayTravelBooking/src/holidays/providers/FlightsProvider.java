package holidays.providers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import holidays.components.Flight;

public class FlightsProvider {

	ArrayList<Flight> flightList = new ArrayList<Flight>();

	public FlightsProvider() {
		loadFlightData();
	}

	/**
	 *  function read the data from Flights.csv file and load the data
	 */
	private void loadFlightData() {

		try {
			File flightData = new File("src/Flights.csv");
			BufferedReader br = new BufferedReader(new FileReader(flightData));
			String st;
			while ((st = br.readLine()) != null) {
				Flight flight = loadFlight(st);
				flightList.add(flight);
			}

		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

	private Flight loadFlight(String st) {
		String flightdetails[] = st.split(",");

		Flight flight = new Flight();
		flight.setCarrierName(flightdetails[0]);
		flight.setFlightName(flightdetails[1]);
		flight.setFromCity(flightdetails[2]);
		flight.setToCity(flightdetails[3]);
		flight.setStartTime(flightdetails[4]);
		flight.setTotaldurationd(flightdetails[5]);
		flight.setFlightDate(flightdetails[6]);
		flight.setCost(Double.parseDouble(flightdetails[7]));
		return flight;
	}


	/**
	 * function gives the  list for flights for given date,departure city and destination city
	 * @param from - departure city
	 * @param to - destination
	 * @param date - travel date
	 * @return list of flights
	 */
	public List<Flight> searchFlightsByKey(String from, String to, String date) {
		List<Flight> searchedFlightList = new ArrayList<>();


		for (Flight ft : flightList) {
			if (ft.getFromCity().equals(from) && ft.getToCity().equals(to) && ft.getFlightDate().equals(date)) {
				searchedFlightList.add(ft);
			}

		}
		return searchedFlightList;
	}


}
