package holidays.providers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import holidays.components.Event;

public class EventsProvider {

	ArrayList<Event> eventList = new ArrayList<Event>();

	public EventsProvider() {
		loadEventData();
	}

	/**
	 *  function read the data from Event.csv file and load the data
	 */
	private void loadEventData() {

		try {
			File eventsData = new File("src/Event.csv");
			BufferedReader br = new BufferedReader(new FileReader(eventsData));
			String st;
			while ((st = br.readLine()) != null) {
				Event evt = loadEvents(st);
				eventList.add(evt);
			}

		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

	private Event loadEvents(String st) {
//		System.out.println(st);
		String eventdetails[] = st.split(",");

		Event evtt = new Event();
		evtt.setCoutryName(eventdetails[0]);
		evtt.setCityName(eventdetails[1]);
		evtt.setEvent(eventdetails[2]);
		evtt.setLocation(eventdetails[3]);
		evtt.setDescription(eventdetails[4]);
//		System.out.println(eventdetails[5]);
		evtt.setEventDate(eventdetails[5]);
		evtt.setCost(Double.parseDouble(eventdetails[6]));
		return evtt;
	}


	/**
	 * function gives the list for events for given country,city and date
	 * @param country
	 * @param city
	 * @param date
	 * @return list of events
	 */
	public List<Event> searchEventsByKey(String country, String city, String date) {
		List<Event> searchedDEventList = new ArrayList<>();
		for (Event et : eventList) {
			if (et.getCoutryName().equals(country) && et.getCityName().equals(city) && et.getEventDate().equals(date)) {
				searchedDEventList.add(et);
			}

		}
		return searchedDEventList;
	}




}
