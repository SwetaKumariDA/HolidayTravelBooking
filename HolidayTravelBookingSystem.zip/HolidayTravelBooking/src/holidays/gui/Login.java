package holidays.gui;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import holidays.customer.CustomerInfo;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JPasswordField;
import javax.swing.UIManager;
import javax.swing.JCheckBox;

public class Login extends JFrame {

	/**
	 * This class represents the login Page and registration page for holiday booking
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField loginUser;
	private static Login frame;
	private JTextField lastName;
	private JTextField firstName;
	private JTextField userId;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	CustomerInfo cust=new CustomerInfo();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the login frame.
	 */
	public Login() {
		setTitle("Welcome to holiday booking system!!!");
		setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 643, 388);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panellogin = new JPanel();
		panellogin.setBackground(Color.DARK_GRAY);
		panellogin.setBounds(0, 0, 304, 349);
		contentPane.add(panellogin);
		panellogin.setLayout(null);

		
		Button button = new Button("LOGIN");
		button.setForeground(Color.WHITE);
		button.setBackground(new Color(0, 204, 204));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				char[] password = passwordField_1.getPassword();
				if (loginUser.getText().isEmpty()) {

					JOptionPane.showMessageDialog(frame, "User Name field can not be left blank", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}
				if (password.length==0) {

					JOptionPane.showMessageDialog(frame, "Password field can not be left blank", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}

				boolean loginValid = validateUserCreds(loginUser.getText(), password);
				if (!loginValid) {
					JOptionPane.showMessageDialog(frame, "Invalid User Name or Password. Please try again", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}
				Users framelogin = new Users(loginUser.getText());
				framelogin.setVisible(true);
				frame.dispose();

			}
		});
		button.setBounds(84, 221, 157, 22);
		panellogin.add(button);

		loginUser = new JTextField();
		loginUser.setForeground(Color.BLACK);
		loginUser.setBackground(Color.WHITE);
		loginUser.setBounds(84, 91, 157, 20);
		panellogin.add(loginUser);
		loginUser.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("User Name");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setBounds(10, 94, 64, 14);
		panellogin.add(lblNewLabel_1);

		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground(Color.WHITE);
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPassword.setBounds(10, 139, 64, 14);
		panellogin.add(lblPassword);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setForeground(Color.BLACK);
		passwordField_1.setBackground(Color.WHITE);
		passwordField_1.setBounds(84, 136, 157, 20);
		panellogin.add(passwordField_1);
		
		JLabel lblNewLabel = new JLabel("ALREADY HAVE AN ACCOUNT?");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setBackground(Color.BLACK);
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setBounds(10, 46, 231, 14);
		panellogin.add(lblNewLabel);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Remember Me");
		chckbxNewCheckBox.setForeground(Color.WHITE);
		chckbxNewCheckBox.setBackground(Color.DARK_GRAY);
		chckbxNewCheckBox.setFont(new Font("Tahoma", Font.PLAIN, 9));
		chckbxNewCheckBox.setBounds(84, 163, 97, 20);
		panellogin.add(chckbxNewCheckBox);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(84, 190, 157, 2);
		panellogin.add(separator);

		JPanel panelregister = new JPanel();
		panelregister.setBackground(Color.BLACK);
		panelregister.setForeground(Color.WHITE);
		panelregister.setToolTipText("");
		panelregister.setBounds(306, 0, 321, 349);
		contentPane.add(panelregister);
		panelregister.setLayout(null);

		
		Button button_1 = new Button("REGISTER");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				char[] password = passwordField.getPassword();
				if (userId.getText().isEmpty() || firstName.getText().isEmpty() || lastName.getText().isEmpty()) {

					JOptionPane.showMessageDialog(frame, "Make sure all registration fields are non-empty", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}

				else if (password.length < 5 || password.length > 10) {
					JOptionPane.showMessageDialog(frame, "Password must be within 5 to 10 chars in length", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}

				boolean userValid = validateUserId(userId.getText());

				if (!userValid)
					return;
				// build comma seperated user details
				StringBuilder sb = new StringBuilder();
				sb.append(userId.getText()).append(",").append(passwordField.getPassword()).append(",")
						.append(firstName.getText()).append(",").append(lastName.getText()).append("\n");

				boolean userAdded = register(sb.toString());
				
				if (userAdded) {
					JOptionPane.showMessageDialog(frame, "Registration Successful!", "Message",
							JOptionPane.PLAIN_MESSAGE);
					Users framelogin = new Users(userId.getText());
					framelogin.setVisible(true);
					frame.dispose();
				} else {
					JOptionPane.showMessageDialog(frame,
							"Error occured while registering user to database. Please try again", "Error",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		button_1.setBounds(114, 269, 146, 22);
		button_1.setBackground(new Color(128, 0, 0));
		panelregister.add(button_1);

		JLabel lblNewLabel_2 = new JLabel("Last Name");
		lblNewLabel_2.setBackground(Color.BLACK);
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2.setBounds(33, 87, 71, 14);
		panelregister.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("First Name");
		lblNewLabel_3.setForeground(UIManager.getColor("Button.highlight"));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_3.setBounds(33, 131, 71, 17);
		panelregister.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("User Name");
		lblNewLabel_4.setForeground(Color.WHITE);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_4.setBounds(33, 178, 71, 14);
		panelregister.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("Password");
		lblNewLabel_5.setForeground(Color.WHITE);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_5.setBounds(33, 225, 71, 14);
		panelregister.add(lblNewLabel_5);

		lastName = new JTextField();
		lastName.setForeground(Color.BLACK);
		lastName.setBackground(Color.WHITE);
		lastName.setBounds(114, 84, 146, 20);
		panelregister.add(lastName);
		lastName.setColumns(10);

		firstName = new JTextField();
		firstName.setForeground(Color.BLACK);
		firstName.setBackground(Color.WHITE);
		firstName.setBounds(114, 129, 146, 20);
		panelregister.add(firstName);
		firstName.setColumns(10);

		userId = new JTextField();
		userId.setForeground(Color.BLACK);
		userId.setBackground(Color.WHITE);
		userId.setBounds(114, 175, 146, 20);
		panelregister.add(userId);
		userId.setColumns(10);

		passwordField = new JPasswordField();
		passwordField.setForeground(Color.BLACK);
		passwordField.setBackground(Color.WHITE);
		passwordField.setBounds(114, 222, 146, 20);
		panelregister.add(passwordField);
		
		JLabel lblSighUpNow = new JLabel("SIGH UP NOW");
		lblSighUpNow.setVerticalAlignment(SwingConstants.TOP);
		lblSighUpNow.setHorizontalAlignment(SwingConstants.LEFT);
		lblSighUpNow.setForeground(Color.WHITE);
		lblSighUpNow.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblSighUpNow.setBackground(Color.BLACK);
		lblSighUpNow.setBounds(33, 46, 208, 14);
		panelregister.add(lblSighUpNow);
	}

	/**
	 * Function validates if the userId already exists or not.
	 * @param userId
	 * @return false if userId already exists, else true
	 */
	public boolean validateUserId(String userId) {
            if(cust.isUserIdExist(userId)) {
					JOptionPane.showMessageDialog(frame, "User already exist. Please try different user id", "Error",
							JOptionPane.ERROR_MESSAGE);
					return false;
				}

		return true;
	}
	
	
	/**
	 * Function validates if the credential given by user is correct or not.
	 * @param userID
	 * @param pass -password
	 * @return true if user credentials are correct.
	 */
	public boolean validateUserCreds(String userID, char[] pass) {
		

		boolean flag=cust.isUserExist(userID,pass);
        return flag;
	}
	
	
	/**Function make the entry for new user in the database.
	 * @param custdetails
	 * @return true if new entry is done successfully.
	 */
	public boolean register(String custdetails) {

		boolean userAdded = cust.writeToDB(custdetails);
		return userAdded;
	}
	
}



