package holidays.gui;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTabbedPane;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import com.toedter.calendar.JDateChooser;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.awt.event.ActionEvent;
import holidays.providers.FlightsProvider;
import holidays.providers.HotelsProvider;
import holidays.providers.RentalCarProviders;
import holidays.providers.EventsProvider;
import holidays.components.Car;
import holidays.components.Flight;
import holidays.components.Hotel;
import holidays.components.RentalCar;
import holidays.components.Room;
import holidays.customer.Customer;
import holidays.customer.CustomerInfo;
import holidays.components.Event;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.JSeparator;
import java.awt.Color;
import java.awt.Font;
import java.awt.Panel;
import javax.swing.JTextField;

public class Users extends JFrame {

	private FlightsProvider fp = new FlightsProvider();
	private HotelsProvider hp = new HotelsProvider();
	private RentalCarProviders rcp = new RentalCarProviders();
	private EventsProvider ep = new EventsProvider();
	private CustomerInfo custInfo = new CustomerInfo();
	private JPanel contentPane;
//	private JTable table_1;
//	private JButton btn_flight_book;
	private JButton button_mydetails;
//	private JButton btn_hotel_book;
//	private JButton btn_rentalCar_book;
	private JButton btnCancelFlight;
	private JButton btnCancelHotel;
	private JButton btnCancelRentalCar;
	private JButton btnCancelEvents;
//	private JButton btnBookEvent;
	private JDateChooser dateChooser_flights;
	private JDateChooser dateChooser_hotel_checkInDate;
	private JDateChooser dateChooser_hotel_checkOutDate;
	private JDateChooser dateChooser_dropOff;
	private JDateChooser dateChooser_pickUp;
	private JDateChooser dateChooser_event_date;
	private String user; // change
	private static final String ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	private Panel panel_1;
	private JLabel label_username;
	private JLabel labelfirstname;
	private JLabel label_lastname;
	private JTextField text_first_name;
	private JTextField text_last_name;
	private JPasswordField text_password;
	private JPanel panel_edit;
	private static Users frame;

	/**
	 * Launch the application.
	 */
	
	/*

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Users("user1");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	*/

	/**
	 * Create the frame.
	 */
	public Users(String loginUser) {
		this.frame = this;
		this.user = loginUser;
		Date date = new Date();

		setTitle("Hello " + loginUser + "! Welcome to holiday booking system");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 848, 551);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(5, 5, 817, 496);
		contentPane.add(tabbedPane);

		String[] airportsFrom = { "SFO", "LHR", "EWR", "LAX", "BOM", "DEL" };

		String[] airportsTo = { "LHR", "SFO", "EWR", "LAX", "BOM", "DEL" };

		JPanel panel_flight = new JPanel();
		panel_flight.setForeground(Color.WHITE);
		panel_flight.setBackground(Color.GRAY);
		tabbedPane.addTab("Flights", null, panel_flight, null);
		tabbedPane.setBackgroundAt(0, Color.LIGHT_GRAY);
		panel_flight.setLayout(null);

		JPanel panel_flight_upper = new JPanel();
		panel_flight_upper.setForeground(Color.WHITE);
		panel_flight_upper.setBackground(Color.GRAY);
		panel_flight_upper.setLayout(null);
		panel_flight_upper.setBounds(0, 0, 812, 92);
		panel_flight.add(panel_flight_upper);
		JComboBox comboBox_flights_from = new JComboBox(airportsFrom);
		comboBox_flights_from.setMaximumRowCount(20);
		comboBox_flights_from.setBackground(Color.GRAY);
		comboBox_flights_from.setForeground(Color.WHITE);
		comboBox_flights_from.setBounds(36, 39, 100, 20);
		panel_flight_upper.add(comboBox_flights_from);

		JLabel lblFlyingFrom = new JLabel("Flying from");
		lblFlyingFrom.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblFlyingFrom.setForeground(Color.WHITE);
		lblFlyingFrom.setBounds(38, 14, 98, 14);
		panel_flight_upper.add(lblFlyingFrom);
		JComboBox comboBox_flights_to = new JComboBox(airportsTo);
		comboBox_flights_to.setMaximumRowCount(20);
		comboBox_flights_to.setBackground(Color.GRAY);
		comboBox_flights_to.setForeground(Color.WHITE);
		comboBox_flights_to.setBounds(202, 39, 100, 20);
		panel_flight_upper.add(comboBox_flights_to);

		JLabel lblFlyingTo = new JLabel("Flying to");
		lblFlyingTo.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblFlyingTo.setForeground(Color.WHITE);
		lblFlyingTo.setBounds(192, 14, 100, 14);
		panel_flight_upper.add(lblFlyingTo);

		JButton button__search_flights = new JButton("Search");
		button__search_flights.setFont(new Font("Tahoma", Font.PLAIN, 11));
		JScrollPane scrollPaneFlight = new JScrollPane();
		JTable tableFlight = new JTable();
		button__search_flights.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				String fromFlight = comboBox_flights_from.getSelectedItem().toString();
				String toFlight = comboBox_flights_to.getSelectedItem().toString();
				DateFormat fmt = new SimpleDateFormat("MMM-d-yyyy");
				String value3 = fmt.format(dateChooser_flights.getDate());
				List<Flight> ft = searchFlights(fromFlight, toFlight, value3);
				int i = 0;
				Object[][] data = new Object[ft.size()][6];
				for (Flight x : ft) {
					data[i][0] = x.getCarrierName();
					data[i][1] = x.getFlightName();
					data[i][2] = x.getStartTime();
					data[i][3] = x.getTotaldurationd();
					data[i][4] = x.getFlightDate();
					data[i][5] = x.getCost();
					i++;

				}
				String[] colHeaders = { "Airlines", "flight Name", "start Time", "Total duration", "Departure date",
						"Cost" };

				scrollPaneFlight.setBounds(20, 103, 770, 300);
				panel_flight.add(scrollPaneFlight);

				DefaultTableModel model5 = new DefaultTableModel(data, colHeaders) {
					public boolean isCellEditable(int row, int column) {
						return false;
					}
				};

				tableFlight.setModel(model5);
				tableFlight.setEnabled(true);
				scrollPaneFlight.setViewportView(tableFlight);
				JButton btn_flight_book = new JButton("Book");
				/*
				 * btn_flight_book.addActionListener(new ActionListener() { public void
				 * actionPerformed(ActionEvent arg0) { } });
				 */
				btn_flight_book.setBounds(371, 418, 89, 23);
				panel_flight.add(btn_flight_book);
				btn_flight_book.setVisible(false);
				btn_flight_book.setVisible(true);
				ListSelectionModel model = tableFlight.getSelectionModel();
				btn_flight_book.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						if (!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							String flightName = tableFlight.getModel().getValueAt(selectedRow, 0).toString();
							String flightCode = tableFlight.getModel().getValueAt(selectedRow, 1).toString();
							String startTime = tableFlight.getModel().getValueAt(selectedRow, 2).toString();
							String totalDuration = tableFlight.getModel().getValueAt(selectedRow, 3).toString();
							String depDate = tableFlight.getModel().getValueAt(selectedRow, 4).toString();
							String cost = tableFlight.getModel().getValueAt(selectedRow, 5).toString();
							int res = JOptionPane.showConfirmDialog(null,
									"You have selected " + flightName + "(" + flightCode + ") departing at " + startTime
											+ " on " + depDate + ". Total Cost would be - " + cost,
									"Confirm Booking", JOptionPane.OK_CANCEL_OPTION);

							StringBuilder sb = new StringBuilder();
							sb.append(user).append(",").append(generateUniqueBookingID()).append(",").append(flightName)
									.append(",").append(flightCode).append(",").append(fromFlight).append(",")
									.append(toFlight).append(",").append(startTime).append(",").append(totalDuration)
									.append(",").append(depDate).append(",").append(cost).append("\n");
							// System.out.println(sb.toString());
							if (res == 0) {
								boolean userAdded = bookFlight(sb.toString());
							}

							// System.out.println(userAdded);

						}

					}
				});

			}
		});
		button__search_flights.setBounds(544, 38, 93, 23);
		panel_flight_upper.add(button__search_flights);

		dateChooser_flights = new JDateChooser();
		dateChooser_flights.setForeground(Color.WHITE);
		dateChooser_flights.setBackground(Color.DARK_GRAY);

		dateChooser_flights.setDate(date);
		dateChooser_flights.setBounds(367, 39, 100, 20);
		panel_flight_upper.add(dateChooser_flights);

		JLabel lblDate = new JLabel("Departing");
		lblDate.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblDate.setForeground(Color.WHITE);
		lblDate.setBounds(367, 14, 97, 14);
		panel_flight_upper.add(lblDate);

		JSeparator separator = new JSeparator();
		separator.setBounds(10, 67, 772, 3);
		panel_flight_upper.add(separator);

//		#####################
		/*JButton btn_flight_book = new JButton("Book");
		
		 * btn_flight_book.addActionListener(new ActionListener() { public void
		 * actionPerformed(ActionEvent arg0) { } });
		 
		btn_flight_book.setBounds(371, 418, 89, 23);
		panel_flight.add(btn_flight_book);
		btn_flight_book.setVisible(false);*/

		JPanel panel_hotel = new JPanel();
		panel_hotel.setBackground(Color.GRAY);
		tabbedPane.addTab("Hotels", null, panel_hotel, null);
		tabbedPane.setBackgroundAt(1, Color.LIGHT_GRAY);
		panel_hotel.setLayout(null);

		JPanel panel_hotel_upper = new JPanel();
		panel_hotel_upper.setBackground(Color.GRAY);
		panel_hotel_upper.setLayout(null);
		panel_hotel_upper.setBounds(0, 0, 812, 92);
		panel_hotel.add(panel_hotel_upper);

		String[] hotelCountry = { "USA" };

		String[] hotelCity = { "santa clara", "San Francisco" };

		JComboBox comboBox_hotel_country = new JComboBox(hotelCountry);
		comboBox_hotel_country.setBackground(Color.GRAY);
		comboBox_hotel_country.setForeground(Color.WHITE);
		comboBox_hotel_country.setBounds(54, 36, 97, 20);
		panel_hotel_upper.add(comboBox_hotel_country);

		JLabel lblCountry = new JLabel("Country");
		lblCountry.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblCountry.setForeground(Color.WHITE);
		lblCountry.setBounds(54, 11, 97, 14);
		panel_hotel_upper.add(lblCountry);

		JComboBox comboBox_hotel_city = new JComboBox(hotelCity);
		comboBox_hotel_city.setForeground(Color.WHITE);
		comboBox_hotel_city.setBackground(Color.GRAY);
		comboBox_hotel_city.setBounds(205, 36, 97, 20);
		panel_hotel_upper.add(comboBox_hotel_city);

		JButton button_search_hotel = new JButton("Search");
		JScrollPane scrollPaneHotel = new JScrollPane();
		JTable tableHotel = new JTable();
		button_search_hotel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				if (dateChooser_hotel_checkOutDate.getDate().compareTo(dateChooser_hotel_checkInDate.getDate()) >= 0) {

					String country = comboBox_hotel_country.getSelectedItem().toString();
					String city = comboBox_hotel_city.getSelectedItem().toString();

					DateFormat fm1 = new SimpleDateFormat("MMM-d-yyyy");
					String checkIndate = fm1.format(dateChooser_hotel_checkInDate.getDate());
					String checkOutdate = fm1.format(dateChooser_hotel_checkOutDate.getDate());
					long days = 0;

					try {
						Date date1 = fm1.parse(checkIndate);
						Date date2 = fm1.parse(checkOutdate);
						long diff = date2.getTime() - date1.getTime();
						days = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
//					System.out.println(days);
					} catch (ParseException e) {
					}
					if (days == 0) {
						days = 1;
					}
					String[] selecteddates = new String[(int) days];
					selecteddates[0] = checkIndate;
					if (days >= 0) {
						Date date;
						int counter = 1;

						while (counter < days) {
							try {

								date = fm1.parse(checkIndate);
								Calendar calendar = Calendar.getInstance();
								calendar.setTime(date);
								calendar.add(Calendar.DAY_OF_YEAR, 1);
								String st = fm1.format(calendar.getTime());
								selecteddates[counter] = st;
//							System.out.println(st);
								checkIndate = st;
								counter++;

							} catch (ParseException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

						}
						for (String st : selecteddates) {
//						System.out.println(st);
						}

						List<Hotel> ft = searchHotels(country, city, selecteddates);
						int i = 0;
						Object[][] data = new Object[ft.size()][7];
						for (Hotel x : ft) {
							data[i][0] = x.getHotelName();
							data[i][1] = x.getDescription();
							Room rm = new Room();
							rm = x.getRoomInfo();

							data[i][2] = rm.getRoomType();
							data[i][3] = rm.getDescription();
							data[i][4] = x.getCheckinTime();
							data[i][5] = x.getCheckoutTime();
							data[i][6] = x.getCost() * days;
//							double t=x.getCost()*days;
							i++;
//					System.out.println(x.getHotelName()+" "+x.getDescription()+" "+x.getCost()+" "+rm.getRoomType()+" ");

						}
						String[] colHeaders = { "hotel Name", "Description", "Room Type", "Room Description ",
								"checkinTime", "checkoutTime", "Cost" };

						scrollPaneHotel.setBounds(10, 103, 780, 300);
						panel_hotel.add(scrollPaneHotel);

						DefaultTableModel model2 = new DefaultTableModel(data, colHeaders) {
							public boolean isCellEditable(int row, int column) {
								return false;
							}

						};

						tableHotel.setModel(model2);
						tableHotel.setEnabled(true);
						scrollPaneHotel.setViewportView(tableHotel);
						JButton btn_hotel_book = new JButton("Book");
						 
						btn_hotel_book.setBounds(369, 412, 89, 23);
						panel_hotel.add(btn_hotel_book);
						btn_hotel_book.setVisible(false);
						btn_hotel_book.setVisible(true);
						ListSelectionModel model = tableHotel.getSelectionModel();
						btn_hotel_book.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent arg0) {
								if (!model.isSelectionEmpty()) {
									int selectedRow = model.getMinSelectionIndex();
									String HotelName = tableHotel.getModel().getValueAt(selectedRow, 0).toString();
									String Description = tableHotel.getModel().getValueAt(selectedRow, 1).toString();
									String RoomType = tableHotel.getModel().getValueAt(selectedRow, 2).toString();
									String Room_Description = tableHotel.getModel().getValueAt(selectedRow, 3)
											.toString();
									String checkinTime = tableHotel.getModel().getValueAt(selectedRow, 4).toString();
									String checkoutTime = tableHotel.getModel().getValueAt(selectedRow, 5).toString();
									String cost = tableHotel.getModel().getValueAt(selectedRow, 6).toString();

									int res = JOptionPane.showConfirmDialog(null, "You have selected " + HotelName,
											"Confirm Hotel Booking", JOptionPane.OK_CANCEL_OPTION);

									StringBuilder sb = new StringBuilder();
									sb.append(user).append(",").append(generateUniqueBookingID()).append(",")
											.append(HotelName).append(",").append(RoomType).append(",")
											.append(checkinTime).append(",").append(checkoutTime).append(",")
											.append(fm1.format(dateChooser_hotel_checkInDate.getDate())).append(",")
											.append(checkOutdate).append(",").append(cost).append("\n");

//									System.out.println(sb.toString());
									if (res == 0) {
										boolean userAdded = bookHotel(sb.toString());
//									System.out.println(userAdded);
									}
								}

							}
						});

					}

				} else {
					JOptionPane.showMessageDialog(null, "Checkout date can not be earlier than Checkin date", null,
							JOptionPane.ERROR_MESSAGE);
				}
			}

		});
		button_search_hotel.setBounds(658, 35, 97, 23);
		panel_hotel_upper.add(button_search_hotel);

		JLabel label_5 = new JLabel("City");
		label_5.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_5.setForeground(Color.WHITE);
		label_5.setBounds(205, 11, 97, 14);
		panel_hotel_upper.add(label_5);

		JLabel lblCheckinDate = new JLabel("CheckIn Date");
		lblCheckinDate.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblCheckinDate.setForeground(Color.WHITE);
		lblCheckinDate.setBounds(356, 11, 97, 14);
		panel_hotel_upper.add(lblCheckinDate);

		dateChooser_hotel_checkInDate = new JDateChooser();
		dateChooser_hotel_checkInDate.setDate(date);
		dateChooser_hotel_checkInDate.setBounds(356, 36, 97, 20);
		panel_hotel_upper.add(dateChooser_hotel_checkInDate);

		JLabel lblCheckoutDate = new JLabel("CheckOut Date");
		lblCheckoutDate.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblCheckoutDate.setForeground(Color.WHITE);
		lblCheckoutDate.setBounds(507, 11, 97, 14);
		panel_hotel_upper.add(lblCheckoutDate);

		dateChooser_hotel_checkOutDate = new JDateChooser();
		dateChooser_hotel_checkOutDate.setDate(date);
		dateChooser_hotel_checkOutDate.setBounds(507, 36, 97, 20);
		panel_hotel_upper.add(dateChooser_hotel_checkOutDate);

		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 67, 772, 3);
		panel_hotel_upper.add(separator_1);

		/*JButton btn_hotel_book = new JButton("Book");
		
		 * btn_hotel_book.addActionListener(new ActionListener() { public void
		 * actionPerformed(ActionEvent e) { } });
		 
		btn_hotel_book.setBounds(369, 412, 89, 23);
		panel_hotel.add(btn_hotel_book);
		btn_hotel_book.setVisible(false);*/

		JPanel panel_rentalCars = new JPanel();
		panel_rentalCars.setBackground(Color.GRAY);
		panel_rentalCars.setForeground(Color.DARK_GRAY);
		tabbedPane.addTab("Rental Cars", null, panel_rentalCars, null);
		tabbedPane.setBackgroundAt(2, Color.LIGHT_GRAY);
		panel_rentalCars.setLayout(null);

		JPanel panel__rentalCars_upper = new JPanel();
		panel__rentalCars_upper.setBackground(Color.GRAY);
		panel__rentalCars_upper.setLayout(null);
		panel__rentalCars_upper.setBounds(0, 0, 812, 92);
		panel_rentalCars.add(panel__rentalCars_upper);

		String[] renatlCarCountry = { "USA" };

		String[] renatlCarCity = { "santa clara", "San Francisco" };

		JComboBox comboBox__rentalCars_country = new JComboBox(renatlCarCountry);
		comboBox__rentalCars_country.setForeground(Color.WHITE);
		comboBox__rentalCars_country.setBackground(Color.GRAY);
		comboBox__rentalCars_country.setBounds(53, 39, 100, 20);
		panel__rentalCars_upper.add(comboBox__rentalCars_country);

		JLabel label = new JLabel("Country");
		label.setFont(new Font("Tahoma", Font.BOLD, 11));
		label.setForeground(Color.WHITE);
		label.setBackground(Color.GRAY);
		label.setBounds(55, 14, 97, 14);
		panel__rentalCars_upper.add(label);

		JComboBox comboBox__rentalCars_city = new JComboBox(renatlCarCity);
		comboBox__rentalCars_city.setForeground(Color.WHITE);
		comboBox__rentalCars_city.setBackground(Color.GRAY);
		comboBox__rentalCars_city.setBounds(206, 39, 100, 20);
		panel__rentalCars_upper.add(comboBox__rentalCars_city);

		JButton button_rentalCars_search = new JButton("Search");
		JScrollPane scrollPaneRentalCar = new JScrollPane();
		JTable tableRentalCar = new JTable();
		button_rentalCars_search.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (dateChooser_dropOff.getDate().compareTo(dateChooser_pickUp.getDate()) >= 0) {

					String country = comboBox__rentalCars_country.getSelectedItem().toString();
					String city = comboBox__rentalCars_city.getSelectedItem().toString();

					DateFormat fm1 = new SimpleDateFormat("MMM-d-yyyy");
					String pickUpDate = fm1.format(dateChooser_pickUp.getDate());
					String dropOffDate = fm1.format(dateChooser_dropOff.getDate());
					long days = 0;

					try {
						Date date1 = fm1.parse(pickUpDate);
						Date date2 = fm1.parse(dropOffDate);
						long diff = date2.getTime() - date1.getTime();
						days = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
//					System.out.println(days);
					} catch (ParseException e1) {
					}
					if (days == 0) {
						days = 1;
					}
					String[] selecteddates = new String[(int) days];
					selecteddates[0] = pickUpDate;
					if (days >= 0) {
						Date date;
						int counter = 1;

						while (counter < days) {
							try {

								date = fm1.parse(pickUpDate);
								Calendar calendar = Calendar.getInstance();
								calendar.setTime(date);
								calendar.add(Calendar.DAY_OF_YEAR, 1);
								String st = fm1.format(calendar.getTime());
								selecteddates[counter] = st;
								pickUpDate = st;
								counter++;

							} catch (ParseException e3) {
								// TODO Auto-generated catch block
								e3.printStackTrace();
							}

						}
						for (String st : selecteddates) {
//						System.out.println(st);
						}

						List<RentalCar> ft = searchRentalCars(country, city, selecteddates);
						int i = 0;
						Object[][] data = new Object[ft.size()][5];
						for (RentalCar x : ft) {
							data[i][0] = x.getServiceProviders();
							Car rm = new Car();
							rm = x.getCarInfo();

							data[i][1] = rm.getCarType();
							data[i][2] = rm.getDescription();
							data[i][3] = x.getCarPickUpLocation();
							data[i][4] = x.getCost() * days;
							i++;
//					System.out.println(x.getServiceProviders()+" "+rm.getCarType());

						}
						String[] colHeaders = { "Service Providers Name", "Car Type", "Car Description ",
								"Car pick-up location", "Cost" };

						scrollPaneRentalCar.setBounds(10, 103, 780, 300);
						panel_rentalCars.add(scrollPaneRentalCar);

						DefaultTableModel model8 = new DefaultTableModel(data, colHeaders) {
							public boolean isCellEditable(int row, int column) {
								return false;
							}

						};

						tableRentalCar.setModel(model8);
						tableRentalCar.setEnabled(true);
						scrollPaneRentalCar.setViewportView(tableRentalCar);
						JButton btn_rentalCar_book = new JButton("Book");
						/*
						 * btn_rentalCar_book.addActionListener(new ActionListener() { public void
						 * actionPerformed(ActionEvent e) { } });
						 */
						btn_rentalCar_book.setBounds(394, 415, 89, 23);
						panel_rentalCars.add(btn_rentalCar_book);
						btn_rentalCar_book.setVisible(false);
						btn_rentalCar_book.setVisible(true);
						ListSelectionModel model = tableRentalCar.getSelectionModel();
						btn_rentalCar_book.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent arg0) {
								if (!model.isSelectionEmpty()) {
									int selectedRow = model.getMinSelectionIndex();
									String serviceProvidersName = tableRentalCar.getModel().getValueAt(selectedRow, 0)
											.toString();
									String carType = tableRentalCar.getModel().getValueAt(selectedRow, 1).toString();
									String cost = tableRentalCar.getModel().getValueAt(selectedRow, 4).toString();

									int res = JOptionPane.showConfirmDialog(null,
											"You have selected " + serviceProvidersName, "Confirm Rental Car Booking",
											JOptionPane.OK_CANCEL_OPTION);

									StringBuilder sb = new StringBuilder();
									sb.append(user).append(",").append(generateUniqueBookingID()).append(",")
											.append(serviceProvidersName).append(",").append(carType).append(",")
											.append(fm1.format(dateChooser_pickUp.getDate())).append(",")
											.append(dropOffDate).append(",").append(cost).append("\n");

									if (res == 0) {
										boolean userAdded = bookRentalCar(sb.toString());
									}

								}

							}
						});
					}

				} else {
					JOptionPane.showMessageDialog(null, "Drop off date can not be earlier than Pickup date", "Error",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		button_rentalCars_search.setBounds(665, 38, 92, 23);
		panel__rentalCars_upper.add(button_rentalCars_search);

		JLabel label_1 = new JLabel("City");
		label_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_1.setForeground(Color.WHITE);
		label_1.setBackground(Color.GRAY);
		label_1.setBounds(206, 14, 100, 14);
		panel__rentalCars_upper.add(label_1);

		JLabel lblPickup = new JLabel("Pick up");
		lblPickup.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPickup.setForeground(Color.WHITE);
		lblPickup.setBackground(Color.GRAY);
		lblPickup.setBounds(360, 14, 99, 14);
		panel__rentalCars_upper.add(lblPickup);

		dateChooser_pickUp = new JDateChooser();
		dateChooser_pickUp.setForeground(Color.WHITE);
		dateChooser_pickUp.setBackground(Color.GRAY);
		dateChooser_pickUp.setDate(date);
		dateChooser_pickUp.setBounds(359, 39, 100, 20);
		panel__rentalCars_upper.add(dateChooser_pickUp);

		JLabel lblDropOff = new JLabel("Drop off");
		lblDropOff.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblDropOff.setForeground(Color.WHITE);
		lblDropOff.setBackground(Color.GRAY);
		lblDropOff.setBounds(513, 14, 99, 14);
		panel__rentalCars_upper.add(lblDropOff);

		dateChooser_dropOff = new JDateChooser();
		dateChooser_dropOff.setForeground(Color.WHITE);
		dateChooser_dropOff.setBackground(Color.GRAY);
		dateChooser_dropOff.setDate(date);
		dateChooser_dropOff.setBounds(512, 39, 100, 20);
		panel__rentalCars_upper.add(dateChooser_dropOff);

		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(10, 67, 772, 3);
		panel__rentalCars_upper.add(separator_2);

		/*JButton btn_rentalCar_book = new JButton("Book");
		
		 * btn_rentalCar_book.addActionListener(new ActionListener() { public void
		 * actionPerformed(ActionEvent e) { } });
		 
		btn_rentalCar_book.setBounds(394, 415, 89, 23);
		panel_rentalCars.add(btn_rentalCar_book);
		btn_rentalCar_book.setVisible(false);*/

		JPanel panel_Holiday_Events = new JPanel();
		panel_Holiday_Events.setBackground(Color.GRAY);
		tabbedPane.addTab("Events", null, panel_Holiday_Events, null);
		tabbedPane.setBackgroundAt(3, Color.LIGHT_GRAY);
		panel_Holiday_Events.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.GRAY);
		panel.setLayout(null);
		panel.setBounds(0, 0, 812, 92);
		panel_Holiday_Events.add(panel);

		String[] EventCountry = { "USA" };

		String[] EventCarCity = { "santa clara", "San Francisco" };

		JComboBox comboBox_event_coutry = new JComboBox(EventCountry);
		comboBox_event_coutry.setForeground(Color.GRAY);
		comboBox_event_coutry.setBounds(79, 39, 100, 20);
		panel.add(comboBox_event_coutry);

		JLabel label_2 = new JLabel("Country");
		label_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_2.setForeground(Color.WHITE);
		label_2.setBounds(81, 14, 97, 14);
		panel.add(label_2);

		JComboBox comboBox_event_city = new JComboBox(EventCarCity);
		comboBox_event_city.setForeground(Color.GRAY);
		comboBox_event_city.setBounds(258, 39, 100, 20);
		panel.add(comboBox_event_city);

		JButton btnSearchEvents = new JButton("Search Events");
		JScrollPane scrollPaneEvent = new JScrollPane();
		JTable tableEvent = new JTable();
		btnSearchEvents.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				String country = comboBox_event_coutry.getSelectedItem().toString();
				String city = comboBox_event_city.getSelectedItem().toString();
				DateFormat fmt = new SimpleDateFormat("MMM-d-yyyy");
				String eventDate = fmt.format(dateChooser_event_date.getDate());
//				System.out.println(value3);

				List<Event> eventlist = searchEvents(country, city, eventDate);
				int i = 0;
				Object[][] data = new Object[eventlist.size()][5];
				for (Event x : eventlist) {
					data[i][0] = x.getEvent();
					data[i][1] = x.getLocation();
					data[i][2] = x.getDescription();
					data[i][3] = x.getEventDate();
					data[i][4] = x.getCost();
					i++;
//					System.out.println(x.getAvailableSeats()+" "+x.getCarrierName()+" "+x.getCost()+" "+x.getFromCity()+" "+x.getToCity());

				}
				String[] colHeaders = { "Event", "Event location", "Event Description", "Event Date", "Cost" };

				scrollPaneEvent.setBounds(10, 103, 780, 300);
				panel_Holiday_Events.add(scrollPaneEvent);

				DefaultTableModel model4 = new DefaultTableModel(data, colHeaders) {
					public boolean isCellEditable(int row, int column) {
						return false;
					}
				};

				tableEvent.setModel(model4);
				tableEvent.setEnabled(true);
				scrollPaneEvent.setViewportView(tableEvent);
				JButton btnBookEvent = new JButton("Book Event");
				btnBookEvent.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
					}
				});
				btnBookEvent.setBounds(339, 412, 134, 23);
				panel_Holiday_Events.add(btnBookEvent);
				btnBookEvent.setVisible(false);
				btnBookEvent.setVisible(true);
				ListSelectionModel model = tableEvent.getSelectionModel();
				btnBookEvent.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						if (!model.isSelectionEmpty()) {
							int selectedRow = model.getMinSelectionIndex();
							String eventName = tableEvent.getModel().getValueAt(selectedRow, 0).toString();
							String eventLOcation = tableEvent.getModel().getValueAt(selectedRow, 1).toString();
							String eventDes = tableEvent.getModel().getValueAt(selectedRow, 2).toString();
							String eventDate = tableEvent.getModel().getValueAt(selectedRow, 3).toString();
							String eventCost = tableEvent.getModel().getValueAt(selectedRow, 4).toString();
							int res = JOptionPane
									.showConfirmDialog(null,
											"You have selected " + eventName + "(" + eventLOcation + ")"
													+ ", Event cost " + eventCost,
											"Confirm Event Booking", JOptionPane.OK_CANCEL_OPTION);

							StringBuilder sb = new StringBuilder();
							sb.append(user).append(",").append(generateUniqueBookingID()).append(",").append(eventName)
									.append(",").append(eventLOcation).append(",").append(eventDes).append(",")
									.append(eventDate).append(",").append(eventCost).append("\n");
//							System.out.println(sb.toString());
							if (res == 0) {
								boolean userAdded = bookEvents(sb.toString());
//							System.out.println(userAdded);
							}
						}

					}
				});
			}
		});
		btnSearchEvents.setBounds(616, 38, 117, 23);
		panel.add(btnSearchEvents);

		JLabel label_6 = new JLabel("City");
		label_6.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_6.setForeground(Color.WHITE);
		label_6.setBounds(258, 14, 100, 14);
		panel.add(label_6);

		JLabel lblEventDate = new JLabel("Event Date");
		lblEventDate.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblEventDate.setForeground(Color.WHITE);
		lblEventDate.setBounds(438, 14, 99, 14);
		panel.add(lblEventDate);

		dateChooser_event_date = new JDateChooser();
		dateChooser_event_date.setForeground(Color.GRAY);
		dateChooser_event_date.setDate(date);
		dateChooser_event_date.setBounds(437, 39, 100, 20);
		panel.add(dateChooser_event_date);

		JSeparator separator_3 = new JSeparator();
		separator_3.setBounds(10, 67, 772, 3);
		panel.add(separator_3);

		/*btnBookEvent = new JButton("Book Event");
		btnBookEvent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnBookEvent.setBounds(339, 412, 134, 23);
		panel_Holiday_Events.add(btnBookEvent);
		btnBookEvent.setVisible(false);*/

		JPanel panel_Bookingdetails = new JPanel();
		panel_Bookingdetails.setBackground(Color.GRAY);
		panel_Bookingdetails.setForeground(Color.BLACK);
		tabbedPane.addTab("Booking Details", null, panel_Bookingdetails, null);
		tabbedPane.setBackgroundAt(4, Color.LIGHT_GRAY);
		panel_Bookingdetails.setLayout(null);

		JButton btnClickToShow = new JButton("Click to show booking details");
		btnClickToShow.setBounds(10, 11, 227, 23);
		panel_Bookingdetails.add(btnClickToShow);

		btnCancelFlight = new JButton("Cancel Flight");
		btnCancelFlight.setBounds(342, 110, 127, 23);
		panel_Bookingdetails.add(btnCancelFlight);
		btnCancelFlight.setVisible(false);

		btnCancelHotel = new JButton("Cancel Hotel");
		btnCancelHotel.setBounds(342, 215, 127, 23);
		panel_Bookingdetails.add(btnCancelHotel);
		btnCancelHotel.setVisible(false);

		btnCancelRentalCar = new JButton("Cancel Car");
		btnCancelRentalCar.setBounds(342, 324, 127, 23);
		panel_Bookingdetails.add(btnCancelRentalCar);
		btnCancelRentalCar.setVisible(false);

		btnCancelEvents = new JButton("Cancel Event");
		btnCancelEvents.setBounds(342, 434, 127, 23);
		panel_Bookingdetails.add(btnCancelEvents);

		JPanel panel_myProfile = new JPanel();
		panel_myProfile.setBackground(Color.GRAY);
		tabbedPane.addTab("My Profile", null, panel_myProfile, null);
		tabbedPane.setBackgroundAt(5, Color.LIGHT_GRAY);
		panel_myProfile.setLayout(null);

		button_mydetails = new JButton("My Details");
		button_mydetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel_1.setVisible(true);
//				Customer cust=new Customer();
//				cust=custact.custDetails(user);	
				String[] myinfo = myDetails();
				label_username.setText(myinfo[0]);
				labelfirstname.setText(myinfo[1]);
				label_lastname.setText(myinfo[2]);

//				label_username.setText(cust.getUserID());
//				labelfirstname.setText(cust.getFirstName());
//				label_lastname.setText(cust.getLastName());

			}
		});
		button_mydetails.setBackground(new Color(255, 127, 80));
		button_mydetails.setBounds(44, 26, 94, 22);
		panel_myProfile.add(button_mydetails);

		panel_1 = new Panel();
		panel_1.setBackground(Color.GRAY);
		panel_1.setBounds(25, 54, 247, 163);
		panel_myProfile.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel = new JLabel("User Name:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(23, 22, 83, 14);
		panel_1.add(lblNewLabel);

		JLabel lblFirstName = new JLabel("First Name:");
		lblFirstName.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblFirstName.setForeground(Color.WHITE);
		lblFirstName.setBounds(23, 58, 83, 14);
		panel_1.add(lblFirstName);

		JLabel lblLastName = new JLabel("Last Name:");
		lblLastName.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblLastName.setForeground(Color.WHITE);
		lblLastName.setBounds(23, 94, 83, 14);
		panel_1.add(lblLastName);

		label_username = new JLabel("");
		label_username.setForeground(Color.WHITE);
		label_username.setFont(new Font("Tahoma", Font.BOLD, 12));
		label_username.setBounds(116, 22, 121, 14);
		panel_1.add(label_username);

		labelfirstname = new JLabel("");
		labelfirstname.setForeground(Color.WHITE);
		labelfirstname.setFont(new Font("Tahoma", Font.BOLD, 12));
		labelfirstname.setBounds(116, 58, 121, 14);
		panel_1.add(labelfirstname);

		label_lastname = new JLabel("");
		label_lastname.setForeground(Color.WHITE);
		label_lastname.setFont(new Font("Tahoma", Font.BOLD, 12));
		label_lastname.setBounds(116, 94, 121, 14);
		panel_1.add(label_lastname);

		JButton btnEditDetails = new JButton("Edit Details");
		btnEditDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String[] myInfo = myDetails();
				text_first_name.setText(myInfo[1]);
				text_last_name.setText(myInfo[2]);
				text_password.setText(myInfo[3]);

				panel_edit.setVisible(true);
			}
		});
		btnEditDetails.setForeground(Color.BLACK);
		btnEditDetails.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnEditDetails.setBounds(98, 129, 139, 23);
		panel_1.add(btnEditDetails);

		panel_edit = new JPanel();
		panel_edit.setBackground(Color.GRAY);
		panel_edit.setBounds(301, 54, 247, 163);
		panel_myProfile.add(panel_edit);
		panel_edit.setLayout(null);
		panel_edit.setVisible(false);

		JLabel label_3 = new JLabel("First Name:");
		label_3.setBounds(10, 22, 67, 15);
		label_3.setForeground(Color.WHITE);
		label_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		panel_edit.add(label_3);

		JLabel label_4 = new JLabel("Last Name:");
		label_4.setForeground(Color.WHITE);
		label_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		label_4.setBounds(10, 59, 83, 14);
		panel_edit.add(label_4);

		JLabel lblPassport = new JLabel("Password:");
		lblPassport.setForeground(Color.WHITE);
		lblPassport.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPassport.setBounds(10, 95, 83, 14);
		panel_edit.add(lblPassport);

		text_first_name = new JTextField();
		text_first_name.setBounds(87, 18, 138, 20);
		panel_edit.add(text_first_name);
		text_first_name.setColumns(10);

		text_last_name = new JTextField();
		text_last_name.setColumns(10);
		text_last_name.setBounds(87, 56, 138, 20);
		panel_edit.add(text_last_name);

		text_password = new JPasswordField();
		text_password.setColumns(10);
		text_password.setBounds(87, 94, 138, 20);
		panel_edit.add(text_password);

		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				updateInfo();
			}
		});
		btnSave.setForeground(Color.BLACK);
		btnSave.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnSave.setBounds(87, 129, 138, 23);
		panel_edit.add(btnSave);
		
		JButton btnSignOut = new JButton("Sign Out");
		btnSignOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (frame!=null)
				 frame.dispose();
				try {
					new Login().main(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		btnSignOut.setBackground(new Color(255, 127, 80));
		btnSignOut.setBounds(718, 11, 94, 22);
		panel_myProfile.add(btnSignOut);
		panel_1.setVisible(false);

		btnCancelEvents.setVisible(false);

		JScrollPane scrollPaneBookedHotel = new JScrollPane();
		JScrollPane scrollPaneBookedFlight = new JScrollPane();
		JTable tableBookedFlight = new JTable();
		JScrollPane scrollPaneBookedCar = new JScrollPane();
		JTable tableBookedHotel = new JTable();
		JTable tableBookedRentCar = new JTable();
		JScrollPane scrollPaneBookedEvent = new JScrollPane();
		JTable tableBookedEvent = new JTable();

		btnClickToShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object[][] resFlight = checkBookedFlight();
				String[] colHeadersFlight = { "Flight Booking details" };

				scrollPaneBookedFlight.setBounds(10, 34, 780, 75);
				panel_Bookingdetails.add(scrollPaneBookedFlight);

				DefaultTableModel model1 = new DefaultTableModel(resFlight, colHeadersFlight) {
					public boolean isCellEditable(int row, int column) {
						return false;
					}

				};

				tableBookedFlight.setModel(model1);
				tableBookedFlight.setEnabled(true);
				scrollPaneBookedFlight.setViewportView(tableBookedFlight);

				Object[][] resHotel = checkBookedHotels();
				String[] colHeadersHotel = { "Hotel Booking details" };

				scrollPaneBookedHotel.setBounds(10, 138, 780, 75);
				panel_Bookingdetails.add(scrollPaneBookedHotel);

				DefaultTableModel model7 = new DefaultTableModel(resHotel, colHeadersHotel) {
					public boolean isCellEditable(int row, int column) {
						return false;
					}

				};

				tableBookedHotel.setModel(model7);
				tableBookedHotel.setEnabled(true);
				scrollPaneBookedHotel.setViewportView(tableBookedHotel);

				Object[][] resRentCar = checkBookedCars();
				String[] colHeadersRentCar = { "Rental Car Booking Details" };

				scrollPaneBookedCar.setBounds(10, 242, 780, 75);
				panel_Bookingdetails.add(scrollPaneBookedCar);

				DefaultTableModel model3 = new DefaultTableModel(resRentCar, colHeadersRentCar) {
					public boolean isCellEditable(int row, int column) {
						return false;
					}

				};

				tableBookedRentCar.setModel(model3);
				tableBookedRentCar.setEnabled(true);
				scrollPaneBookedCar.setViewportView(tableBookedRentCar);

				Object[][] resEvent = checkBookedEvents();
				String[] colHeadersEvent = { "Event Booking Details" };

				scrollPaneBookedEvent.setBounds(10, 350, 780, 75);
				panel_Bookingdetails.add(scrollPaneBookedEvent);

				DefaultTableModel model6 = new DefaultTableModel(resEvent, colHeadersEvent) {
					public boolean isCellEditable(int row, int column) {
						return false;
					}

				};

				tableBookedEvent.setModel(model6);
				tableBookedEvent.setEnabled(true);
				scrollPaneBookedEvent.setViewportView(tableBookedEvent);

				btnCancelFlight.setVisible(true);
				btnCancelHotel.setVisible(true);
				btnCancelRentalCar.setVisible(true);
				btnCancelEvents.setVisible(true);

				ListSelectionModel modelFlight = tableBookedFlight.getSelectionModel();
				ListSelectionModel modelHotel = tableBookedHotel.getSelectionModel();
				ListSelectionModel modelCar = tableBookedRentCar.getSelectionModel();
				ListSelectionModel modelEvent = tableBookedEvent.getSelectionModel(); // change table here

				btnCancelFlight.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						if (!modelFlight.isSelectionEmpty()) {
							int selectedRow = modelFlight.getMinSelectionIndex();
							String BookedFlight = tableBookedFlight.getModel().getValueAt(selectedRow, 0).toString();
							if ("No flight reservation".equals(BookedFlight)) {
								return;
							}
							int res = JOptionPane.showConfirmDialog(null, "You want to cancel " + BookedFlight,
									"Confirm Flight Cancellation", JOptionPane.OK_CANCEL_OPTION);
							if (res == 0) {
								String BookingId = BookedFlight.split("#")[1];
								boolean cancel = cancelFlight(BookingId);
								if (cancel) {
									JOptionPane.showMessageDialog(null,
											"You " + BookedFlight + " was cancelled successfully.", "Confirmation",
											JOptionPane.DEFAULT_OPTION);
								}
								btnClickToShow.doClick();
							}

						}

					}
				});

				btnCancelHotel.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						if (!modelHotel.isSelectionEmpty()) {
							int selectedRow = modelHotel.getMinSelectionIndex();
							String BookedHotels = tableBookedHotel.getModel().getValueAt(selectedRow, 0).toString();
							if ("No Hotel reservation".equals(BookedHotels)) {
								return;
							}
							int res = JOptionPane.showConfirmDialog(null, "You want to cancel " + BookedHotels,
									"Confirm Hotel Cancellation", JOptionPane.OK_CANCEL_OPTION);
							if (res == 0) {
								String BookingId = BookedHotels.split("#")[1];
								boolean cancel = cancelHotel(BookingId);
								if (cancel) {
									JOptionPane.showMessageDialog(null,
											"You " + BookedHotels + " was cancelled successfully.", "Confirmation",
											JOptionPane.DEFAULT_OPTION);
								}
								btnClickToShow.doClick();
							}

						}

					}
				});

				btnCancelRentalCar.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						if (!modelCar.isSelectionEmpty()) {
							int selectedRow = modelCar.getMinSelectionIndex();
							String bookedCar = tableBookedRentCar.getModel().getValueAt(selectedRow, 0).toString();
							if ("No Rental car reservation found".equals(bookedCar)) {
								return;
							}
							int res = JOptionPane.showConfirmDialog(null, "You want to cancel " + bookedCar,
									"Confirm Car Cancellation", JOptionPane.OK_CANCEL_OPTION);
							if (res == 0) {
								String BookingId = bookedCar.split("#")[1];
								boolean cancel = cancelRentalCar(BookingId);
								if (cancel) {
									JOptionPane.showMessageDialog(null,
											"You " + bookedCar + " was cancelled successfully.", "Confirmation",
											JOptionPane.DEFAULT_OPTION);
								}
								btnClickToShow.doClick();
							}

						}

					}
				});

				btnCancelEvents.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						if (!modelEvent.isSelectionEmpty()) {
							int selectedRow = modelEvent.getMinSelectionIndex();
							String bookedEvent = tableBookedEvent.getModel().getValueAt(selectedRow, 0).toString();
							if ("No Event reservation found".equals(bookedEvent)) {
								return;
							}
							int res = JOptionPane.showConfirmDialog(null, "You want to cancel " + bookedEvent,
									"Confirm Event Cancellation", JOptionPane.OK_CANCEL_OPTION);
							if (res == 0) {
								String BookingId = bookedEvent.split("#")[1];
								boolean cancel = cancelEvent(BookingId);
								if (cancel) {
									JOptionPane.showMessageDialog(null,
											"You " + bookedEvent + " was cancelled successfully.", "Confirmation",
											JOptionPane.DEFAULT_OPTION);
								}
								btnClickToShow.doClick();
							}

						}

					}
				});

			}
		});

	}

	/**
	 * function gives the  list for flights for given date,departure city and destination city
	 * @param from - departure city
	 * @param to - destination
	 * @param date - travel date
	 * @return list of flights
	 */
	public List<Flight> searchFlights(String from, String to, String date) {
		List<Flight> ft = fp.searchFlightsByKey(from, to, date);
		return ft;

	}

	/** function gives the list for hotels for given country,city and date
	 * @param country 
	 * @param city
	 * @param userDates
	 * @return list of hotels
	 */
	public List<Hotel> searchHotels(String country, String city, String[] userDates) {
		List<Hotel> ft = hp.searchHotelsByKey(country, city, userDates);
		return ft;

	}

	/** 
	 * function gives the list for rental cars for given country,city and date
	 * @param country
	 * @param city
	 * @param userDates
	 * @return list of rental cars
	 */
	public List<RentalCar> searchRentalCars(String country, String city, String[] userDates) {
		List<RentalCar> ft = rcp.carsByKey(country, city, userDates);
		return ft;

	}

	/**
	 * function gives the list for events for given country,city and date
	 * @param country
	 * @param city
	 * @param eventDate
	 * @return list of events
	 */
	public List<Event> searchEvents(String country, String city, String eventDate) {
		List<Event> ft = ep.searchEventsByKey(country, city, eventDate);
		return ft;

	}

	/** Function cancel the selected flight
	 * @param BookingId
	 * @return true if cancellation is done successfully otherwise false.
	 */
	public boolean cancelFlight(String BookingId) {
		boolean successful = false;
		File inputFile = new File("src/FlightBookingDetails.csv");
		// File tempFile = new File("src/myTempFile.csv");
		BufferedReader reader = null;
		BufferedWriter out = null;
		try {

			reader = new BufferedReader(new FileReader(inputFile));
			String currentLine;
			StringBuffer sb = new StringBuffer();

			while ((currentLine = reader.readLine()) != null) {
				// trim newline when comparing with lineToRemove
//			System.out.println(currentLine);
				String trimmedLine = currentLine.trim();
				if (trimmedLine.contains(BookingId))
					continue;
				// System.out.println(currentLine);
				sb.append(currentLine);
				sb.append("\n");
			}
			reader.close();
			out = new BufferedWriter(new FileWriter(inputFile));
			out.write(sb.toString());
			out.close();
			successful = true;
		} catch (IOException e) {

		} finally {
			try {
				if (out != null)
					out.close();
				if (reader != null)
					reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return successful;
	}

	/** Function cancel the selected hotel
	 * @param BookingId
	 * @return true if cancellation is done successfully otherwise false.
	 */
	public boolean cancelHotel(String BookingId) {
		boolean successful = false;
		File inputFile = new File("src/HotelsBookingDetails.csv");
		BufferedReader reader = null;
		BufferedWriter out = null;
		try {

			reader = new BufferedReader(new FileReader(inputFile));
			String currentLine;
			StringBuffer sb = new StringBuffer();

			while ((currentLine = reader.readLine()) != null) {
				// trim newline when comparing with lineToRemove
//			System.out.println(currentLine);
				String trimmedLine = currentLine.trim();
				if (trimmedLine.contains(BookingId))
					continue;
				// System.out.println(currentLine);
				sb.append(currentLine);
				sb.append("\n");
			}
			reader.close();
			out = new BufferedWriter(new FileWriter(inputFile));
			out.write(sb.toString());
			out.close();
			successful = true;
		} catch (IOException e) {

		} finally {
			try {
				if (out != null)
					out.close();
				if (reader != null)
					reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return successful;
	}

	/** Function cancel the selected rental car
	 * @param BookingId
	 * @return true if cancellation is done successfully otherwise false.
	 */
	public boolean cancelRentalCar(String BookingId) {
		boolean successful = false;
		File inputFile = new File("src/RentalCarsBookingDetails.csv");
		BufferedReader reader = null;
		BufferedWriter out = null;
		try {

			reader = new BufferedReader(new FileReader(inputFile));
			String currentLine;
			StringBuffer sb = new StringBuffer();

			while ((currentLine = reader.readLine()) != null) {
				// trim newline when comparing with lineToRemove
//			System.out.println(currentLine);
				String trimmedLine = currentLine.trim();
				if (trimmedLine.contains(BookingId))
					continue;
				// System.out.println(currentLine);
				sb.append(currentLine);
				sb.append("\n");
			}
			reader.close();
			out = new BufferedWriter(new FileWriter(inputFile));
			out.write(sb.toString());
			out.close();
			successful = true;
		} catch (IOException e) {

		} finally {
			try {
				if (out != null)
					out.close();
				if (reader != null)
					reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return successful;
	}

	/** Function cancel the selected event
	 * @param BookingId
	 * @return true if cancellation is done successfully otherwise false.
	 */
	public boolean cancelEvent(String BookingId) {
		boolean successful = false;
		File inputFile = new File("src/EventBookingDetails.csv");
		BufferedReader reader = null;
		BufferedWriter out = null;
		try {

			reader = new BufferedReader(new FileReader(inputFile));
			String currentLine;
			StringBuffer sb = new StringBuffer();

			while ((currentLine = reader.readLine()) != null) {
				// trim newline when comparing with lineToRemove
//			System.out.println(currentLine);
				String trimmedLine = currentLine.trim();
				if (trimmedLine.contains(BookingId))
					continue;
				// System.out.println(currentLine);
				sb.append(currentLine);
				sb.append("\n");
			}
			reader.close();
			out = new BufferedWriter(new FileWriter(inputFile));
			out.write(sb.toString());
			out.close();
			successful = true;
		} catch (IOException e) {

		} finally {
			try {
				if (out != null)
					out.close();
				if (reader != null)
					reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return successful;
	}

	/**
	 * Function gives the list of flights booked by the user
	 * @return flight list 
	 */
	public Object[][] checkBookedFlight() {
		List<String> list = new ArrayList<>();
		try {
			File flightData = new File("src/FlightBookingDetails.csv");
			BufferedReader br = new BufferedReader(new FileReader(flightData));
			String st;

			int i = 0;
			while ((st = br.readLine()) != null) {
				String[] a = st.split(",");
				if (user.equals(a[0])) {
					list.add(a[2] + "(" + a[3] + "). BookingID #" + a[1] + "#. Departs " + a[4] + a[6] + " on " + a[8]
							+ ". Arrives " + a[5] + " Total cost: " + a[9]);
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int i = 0;
		if (list.isEmpty()) {
			list.add("No flight reservation");
		}
		Object[][] resList = new Object[list.size()][1];
		for (String str : list) {
			resList[i++][0] = str;
		}
		return resList;
	}

	/**
	 * Function gives the list of hotels booked by the user
	 * @return hotel list 
	 */
	public Object[][] checkBookedHotels() {
		List<String> list = new ArrayList<>();
		try {
			File flightData = new File("src/HotelsBookingDetails.csv");
			BufferedReader br = new BufferedReader(new FileReader(flightData));
			String st;

			int i = 0;
			while ((st = br.readLine()) != null) {
				String[] a = st.split(",");
				if (user.equals(a[0])) {
					list.add(a[2] + ", BookingID #" + a[1] + "#. Check in Date " + a[6] + " Check out date " + a[7]
							+ " Total cost: " + a[8]);
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int i = 0;
		if (list.isEmpty()) {
			list.add("No Hotel reservation");
		}
		Object[][] resList = new Object[list.size()][1];
		for (String str : list) {
			resList[i++][0] = str;
		}
		return resList;
	}

	/**
	 * Function gives the list of rental cars booked by the user
	 * @return booked car list 
	 */
	public Object[][] checkBookedCars() {
		List<String> list = new ArrayList<>();
		try {
			File flightData = new File("src/RentalCarsBookingDetails.csv");
			BufferedReader br = new BufferedReader(new FileReader(flightData));
			String st;

			int i = 0;
			while ((st = br.readLine()) != null) {
				String[] a = st.split(",");
				if (user.equals(a[0])) {
					list.add("Booked " + a[3] + ", car at, " + a[2] + " Booking #" + a[1] + "# .Car pick up Date "
							+ a[4] + "and car drop off date " + a[5] + " Total cost: " + a[6]);
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int i = 0;
		if (list.isEmpty()) {
			list.add("No Rental car reservation found");
		}
		Object[][] resList = new Object[list.size()][1];
		for (String str : list) {
			resList[i++][0] = str;
		}
		return resList;
	}

	/**
	 * Function gives the list of events booked by the user
	 * @return event list 
	 */
	public Object[][] checkBookedEvents() {
		List<String> list = new ArrayList<>();
		try {
			File eventData = new File("src/EventBookingDetails.csv");
			BufferedReader br = new BufferedReader(new FileReader(eventData));
			String st;

			int i = 0;
			while ((st = br.readLine()) != null) {
				String[] a = st.split(",");
				if (user.equals(a[0])) {
					list.add("Event " + a[2] + ", location, " + a[3] + " is on " + a[5] + " Booking #" + a[1]
							+ "# Total cost: " + a[6]);
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int i = 0;
		if (list.isEmpty()) {
			list.add("No Event  reservation found");
		}
		Object[][] eventList = new Object[list.size()][1];
		for (String str : list) {
			eventList[i++][0] = str;
		}
		return eventList;
	}

	
	/**
	 *  Function updates the user information in the database
	 */
	public void updateInfo() {
		String[] myInfo = myDetails();
		char[] password = text_password.getPassword();
		if (text_first_name.getText().trim().isEmpty() || text_last_name.getText().trim().isEmpty()) {

			JOptionPane.showMessageDialog(null, "Make sure First name and Last name are non-empty", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		else if (password.length < 5 || password.length > 10) {
			JOptionPane.showMessageDialog(null, "Password must be within 5 to 10 chars in length", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		String userId = myInfo[0];
		// build comma separated user details
		StringBuilder sb = new StringBuilder();
		sb.append(userId).append(",").append(text_password.getPassword()).append(",").append(text_first_name.getText().trim())
				.append(",").append(text_last_name.getText().trim()).append("\n");
System.out.println(sb);
		File inputFile = new File("src/CustomerInfo.csv");
		BufferedReader reader = null;
		BufferedWriter out = null;
		try {

			reader = new BufferedReader(new FileReader(inputFile));
			String currentLine;
			StringBuffer sb1 = new StringBuffer();

			while ((currentLine = reader.readLine()) != null) {
				// trim newline when comparing with lineToRemove
//			System.out.println(currentLine);
				String trimmedLine = currentLine.trim();
				if (trimmedLine.contains(userId)) {
					sb1.append(sb.toString());
					continue;
				}
				// System.out.println(currentLine);
				sb1.append(currentLine);
				sb1.append("\n");
			}
			reader.close();
			out = new BufferedWriter(new FileWriter(inputFile));
			out.write(sb1.toString());
			out.close();
			Customer cust = custInfo.custDetails(user);
			cust.setFirstName(text_first_name.getText());
			cust.setLastName(text_last_name.getText());
			cust.setPassword(new String(text_password.getPassword()));
			panel_edit.setVisible(false);
			button_mydetails.doClick();
		} catch (IOException e) {

		} finally {
			try {
				if (out != null)
					out.close();
				if (reader != null)
					reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	/** Function books the selected flight and write into the database
	 * @param Details
	 * @return true if booking is successful, otherwise false
	 */
	public boolean bookFlight(String Details) {
		try {

			// Open given file in append mode.
			BufferedWriter out = new BufferedWriter(new FileWriter("src/FlightBookingDetails.csv", true));
			out.write(Details);
			out.close();
		} catch (IOException e) {
			System.out.println("exception occoured while booking" + e);
			return false;
		}
		return true;

	}
	
	/** Function books the selected hotel and write into the database
	 * @param Details
	 * @return true if booking is successful, otherwise false
	 */
	public boolean bookHotel(String Details) {
		try {

			// Open given file in append mode.
			BufferedWriter out = new BufferedWriter(new FileWriter("src/HotelsBookingDetails.csv", true));
			out.write(Details);
			out.close();
		} catch (IOException e) {
			System.out.println("exception occoured while booking" + e);
			return false;
		}
		return true;

	}

	/** Function books the selected rental car and write into the database
	 * @param Details
	 * @return true if booking is successful, otherwise false
	 */
	public boolean bookRentalCar(String Details) {
		try {

			// Open given file in append mode.
			BufferedWriter out = new BufferedWriter(new FileWriter("src/RentalCarsBookingDetails.csv", true));
			out.write(Details);
			out.close();
		} catch (IOException e) {
			System.out.println("exception occoured while booking" + e);
			return false;
		}
		return true;

	}

	/** Function books the selected events and write into the database
	 * @param Details
	 * @return true if booking is successful, otherwise false
	 */
	public boolean bookEvents(String Details) {
		try {

			// Open given file in append mode.
			BufferedWriter out = new BufferedWriter(new FileWriter("src/EventBookingDetails.csv", true));
			out.write(Details);
			out.close();
		} catch (IOException e) {
			System.out.println("exception occoured while booking" + e);
			return false;
		}
		return true;

	}

	/** Function queries the user details
	 * @return user details
	 */
	public String[] myDetails() {
		Customer cust = new Customer();
		cust = custInfo.custDetails(user);
		String[] myinfo = new String[4];
		myinfo[0] = cust.getUserID();
		myinfo[1] = cust.getFirstName();
		myinfo[2] = cust.getLastName();
		myinfo[3] = cust.getPassword();
		return myinfo;

	}

	/** function generates alpha numeric bookingId
	 * @return string of bookingId
	 */
	public static String generateUniqueBookingID() {
		int length = 6;
		Random random = new Random();
		StringBuilder builder = new StringBuilder(length);

		for (int i = 0; i < length; i++) {
			builder.append(ALPHABET.charAt(random.nextInt(ALPHABET.length())));
		}

		return builder.toString();
	}
}
