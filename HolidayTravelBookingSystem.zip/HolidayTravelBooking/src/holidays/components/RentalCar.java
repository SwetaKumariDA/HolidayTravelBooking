package holidays.components;

public class RentalCar {
	private String countryName;
	private String cityName;
	private String serviceProviders;
	private String carPickUpLocation;
	private String dateAvailability;
	private double cost;
	private Car carInfo;
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getServiceProviders() {
		return serviceProviders;
	}
	public void setServiceProviders(String serviceProviders) {
		this.serviceProviders = serviceProviders;
	}
	public String getCarPickUpLocation() {
		return carPickUpLocation;
	}
	public void setCarPickUpLocation(String carPickUpLocation) {
		this.carPickUpLocation = carPickUpLocation;
	}
	public String getDateAvailability() {
		return dateAvailability;
	}
	public void setDateAvailability(String dateAvailability) {
		this.dateAvailability = dateAvailability;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public Car getCarInfo() {
		return carInfo;
	}
	public void setCarInfo(Car carInfo) {
		this.carInfo = carInfo;
	}


}
