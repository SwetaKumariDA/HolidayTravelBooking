package holidays.components;

public class Hotel {
	private String hotelName;
	private String description;
	private String countryName;
	private String cityName;
	private String checkinTime;
	private String checkoutTime;
	private String dateAvailability;
	private double cost;
	private Room roomInfo;
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getCheckinTime() {
		return checkinTime;
	}
	public void setCheckinTime(String checkinTime) {
		this.checkinTime = checkinTime;
	}
	public String getCheckoutTime() {
		return checkoutTime;
	}
	public void setCheckoutTime(String checkoutTime) {
		this.checkoutTime = checkoutTime;
	}
	public String getDateAvailability() {
		return dateAvailability;
	}
	public void setDateAvailability(String dateAvailability) {
		this.dateAvailability = dateAvailability;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public Room getRoomInfo() {
		return roomInfo;
	}
	public void setRoomInfo(Room roomInfo) {
		this.roomInfo = roomInfo;
	}
	
	
	
	
}
